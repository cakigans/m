# TAFA (Toolkit For Facebook)
![LOGO](https://github.com/salismazaya/TAFA/blob/master/Screenshot%20(2).png)
# requirements
- python 3.x
- module requests
- module bs4
- module mechanize
# features
- login using cookies (this method is safer than using token)
- spam like in friend timeline, groups, fanspage, and home
- spam react in friend timeline, groups, fanspage, and home
- spam comment in friend timeline, groups, fanspage, and home
- unfriends all friend
- unadd all friend
- accept & reject all friend requests
- and more
# install in termux
- pkg install git python -y
- git clone https://github.com/salismazaya/TAFA
- pip install requests bs4 mehchanize

Don't forget give me star ^_^
# TAFA (Toolkit For Facebook)
![LOGO](https://github.com/salismazaya/TAFA/blob/master/Screenshot%20(2).png)
# requirements
- python 3.x
- module requests
- module bs4
- module mechanize
# features
- login using cookies (this method is safer than using token)
- spam like in friend timeline, groups, fanspage, and home
- spam react in friend timeline, groups, fanspage, and home
- spam comment in friend timeline, groups, fanspage, and home
- unfriends all friend
- unadd all friend
- accept & reject all friend requests
- and more
# install in termux
- pkg install git python -y
- git clone https://github.com/salismazaya/TAFA
- pip install requests bs4 mehchanize

Don't forget give me star ^_^
