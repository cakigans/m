

```
				 ________.   .__ 
			       _/ ____\_ |__ |__|
			       \   __\ | __ \|  |
				|  |   | \_\ \  |
				|__|   |___  /__|
                                           \/    
                                       
                                       FBI
                             [Facebook Informations]
```
FBI is an accurate facebook account information gathering, all sensitive information can be easily gathered even though the target converts all of its privacy to (only me), Sensitive information about residence, date of birth, occupation, phone number and email address.



# [ Installation ]
```
$ apt update && apt upgrade
$ apt install git python2
$ git clone https://github.com/xHak9x/fbi.git
$ cd fbi
```

# [ Setup ]
```
$ pip2 install -r requirements.txt
```
# [ Running ]
```
$ python2 fbi.py
```
# [ Screenshot ]
<img src="https://image.ibb.co/iLFhD9/fbi.png"/>

* if you are confused how to use it, please type 'help' to display the help menu
* [Warn] please turn off your VPN before using this program !!!
* [Tips] do not overuse this program !!!

![](https://image.ibb.co/i4ES3U/bc.png)

   ![](https://image.ibb.co/iniWV9/electrum_3_2_2_2018_08_30_21_49_44.png)

Bitcoin: 1A3a1p22EHXWq7muYZc9rGTmRGaithMnjR
