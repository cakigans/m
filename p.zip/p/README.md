# MBF COOKIE VERSION

• pip2 install requests bs4
